<!-- copyright and contactUs fixed footer -->

<!DOCTYPE html>
<html>
<head>
<style>
.footer {
    position: fixed;
    width: 100%;
    text-align: center;
    
   
}
</style>
</head>
<body>
<footer class="footer">

  <p style="margin-top: 4px;margin-bottom:-10px">      </p><br>
  <a href="mailto:vinayksgowda@gmail.com" style="color:brown">  </a>

</footer>

</body>
</html>
